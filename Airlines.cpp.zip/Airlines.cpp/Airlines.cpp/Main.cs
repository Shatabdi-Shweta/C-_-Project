﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airlines.cpp
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

    

        private void addNewFlightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Flight_Information flight = new Flight_Information();
            flight. MdiParent = this;
            flight.Show();

        }

        private void addNewCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.MdiParent = this;
            customer.Show();

        }

        private void searchCustomerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Search_Customer search = new Search_Customer();
            search.MdiParent = this;
            search.Show();
        }

        private void bookTicketToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ticket_Reservation ticket = new Ticket_Reservation();
            ticket.MdiParent = this;
            ticket.Show();

        }
    }
}
