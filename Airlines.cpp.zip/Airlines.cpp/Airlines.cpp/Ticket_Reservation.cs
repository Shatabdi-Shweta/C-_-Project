﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airlines.cpp
{
    public partial class Ticket_Reservation : Form
    {
        AirlinesDbEntities Db;
        public Ticket_Reservation()
        {
            InitializeComponent();
            Db = new AirlinesDbEntities();
            BindSource();
            BindDestination();

        }

        private void BindDestination()
        {
            var items = Db.Flight_Details.ToList();
            destinationCombo.DataSource = items;
            destinationCombo.DisplayMember = "Destination";
        }

        private void BindSource()
        {
            var items = Db.Flight_Details.ToList();
            sourceCombo.DataSource = items;
            sourceCombo.DisplayMember = "Source";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(sourceCombo.Text!=destinationCombo.Text)
            {
                dataGridView1.DataSource = Db.Flight_Details.Where(a => a.Source == sourceCombo.Text).ToList();
                dataGridView1.DataSource = Db.Flight_Details.Where(a => a.Destination == destinationCombo.Text).ToList();

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(customeridtxt.Text);
            var items = Db.Customer_Details.Where(a => a.Id ==id) .FirstOrDefault();
            customernametxt.Text = items.Name;
            fathertxt.Text = items.Father_s_Name;
            mothertxt.Text = items.Mother_s_Name;
            dateTimePicker1.Value = (DateTime)items.Date_of_Birth;
            emailtxt.Text = items.Email;
            phnnotxt.Text = items.Phone_Number;
            addresstxt.Text = items.Address;

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            var flightId = dataGridView1.SelectedRows[0].Cells[0].Value;
            flightidtxt.Text = flightId.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(seatnotxt.Text) == 0 || Convert.ToInt32(seatnotxt.Text) < 0)
            {
                MessageBox.Show("invalid");
            }
            else
            {
                if (Convert.ToInt32(seatnotxt.Text) > 0 && Convert.ToInt32(seatnotxt.Text) <= 50)
                {
                    if (AvailableSeat() == true)
                    {
                        Booking booking = new Booking();
                        booking.Customer_Id = Convert.ToInt32(customeridtxt.Text);
                        booking.Date_of_Journey = dateTimePicker2.Value;
                        booking.Flight_Id = Convert.ToInt32(flightidtxt.Text);
                        booking.Seat_No = Convert.ToInt32(seatnotxt.Text);
                        Db.Bookings.Add(booking);
                        Db.SaveChanges();
                        MessageBox.Show("Add Ticket");
                    }
                    else
                    {
                        MessageBox.Show("Seat no is already booked");
                    }
                }
                else
                {
                    MessageBox.Show("Available Seat no is less than 50 or equal to 50 ");
                }


            }      
                   
        }
         
        

        private bool AvailableSeat()
        {
            int flightId = Convert.ToInt32(flightidtxt.Text);
            int seatNo = Convert.ToInt32(seatnotxt.Text);
            string dateOfJourney = dateTimePicker2.Value.ToString("DD/MM/YYYY");
            var item = Db.Bookings.Where(a => a.Flight_Id == flightId && a.Seat_No==seatNo).FirstOrDefault();
           if(item != null)
            {
                string ExistsDate = ((DateTime)item.Date_of_Journey).ToString("DD/MM/YYYY");
                if(ExistsDate==dateOfJourney)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            return true;
        }
    }
}
