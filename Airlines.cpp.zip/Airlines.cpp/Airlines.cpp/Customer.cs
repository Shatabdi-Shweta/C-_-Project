﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airlines.cpp
{
    public partial class Customer : Form
    {
        AirlinesDbEntities Db;
        static int id = 0;
        public Customer([Optional] int? Id)
        {
            InitializeComponent();
            if ( Id !=null)
            {
                button1.Visible = false;
                Db = new AirlinesDbEntities();
                Customer_Details customer = Db.Customer_Details.Where(a => a.Id == Id).FirstOrDefault();
                id = customer.Id;
                nametxt.Text = customer.Name;
                fathertxt.Text = customer.Father_s_Name;
                mothertxt.Text = customer.Mother_s_Name;
                datetxt.Value = (DateTime)customer.Date_of_Birth;
                emailtxt.Text = customer.Email;
                phnnumtxt.Text = customer.Phone_Number;
                addresstxt.Text = customer.Address;

            }
            else
            {
                button2.Visible = false;
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {
            AirlinesDbEntities Db = new AirlinesDbEntities();
            Customer_Details customer = new Customer_Details
            {
                Name = nametxt.Text,
                Father_s_Name = fathertxt.Text,
                Mother_s_Name = mothertxt.Text,
                Date_of_Birth = datetxt.Value,
                Email = emailtxt.Text,
                Phone_Number = phnnumtxt.Text,
                Address = addresstxt.Text,
            };
            Db.Customer_Details.Add(customer);
            Db.SaveChanges();
            MessageBox.Show("Add one customer");

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Db = new AirlinesDbEntities();
            Customer_Details customer = Db.Customer_Details.Where(a => a.Id == id).FirstOrDefault();
            customer.Name = nametxt.Text;
            customer.Father_s_Name= fathertxt.Text ;
            customer.Mother_s_Name= mothertxt.Text ;
            customer.Date_of_Birth = datetxt.Value ;
            customer.Email= emailtxt.Text ;
            customer.Phone_Number= phnnumtxt.Text ;
            customer.Address = addresstxt.Text ;
            Db.SaveChanges();
            MessageBox.Show("Record updated");

        }
    }
}
