﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airlines.cpp
{
    public partial class Search_Customer : Form
    {
        public Search_Customer()
        {
            InitializeComponent();
        }


        private void Search_Customer_Load(object sender, EventArgs e)
        {
            AirlinesDbEntities Db = new AirlinesDbEntities();
            var items = Db.Customer_Details.ToList();
            dataGridView1.DataSource = items;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            AirlinesDbEntities Db = new AirlinesDbEntities();
            var items = Db.Customer_Details.Where(a=>a.Name.Equals(textBox1.Text)).ToList();
            dataGridView1.DataSource = items;
        }

       

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
            Customer c1 = new Customer(id);
            c1.ShowDialog();

        }
    }
}
