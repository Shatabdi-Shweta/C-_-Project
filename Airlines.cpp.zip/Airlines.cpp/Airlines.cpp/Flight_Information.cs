﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Airlines.cpp
{
    public partial class Flight_Information : Form
    {
        AirlinesDbEntities Db;
        public Flight_Information()
        {
            InitializeComponent();
            Db = new AirlinesDbEntities();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            Flight_Details fd = new Flight_Details();
            fd.Flight_Name = flightnametxt.Text;
            fd.Source = sourcetxt.Text;
            fd.Destination = destinationtxt.Text;
            fd.Departure_Time = depaturetxt.Text;
            fd.Arrival_Time = arrivaltxt.Text;
            fd.Flight_Class = flighrclasstxt.Text;
            fd.Flight_Charges = Convert.ToDecimal(flightchargetxt.Text);
            fd.Flight_Seats=Convert.ToInt16(flightseattxt.Text);
            Db.Flight_Details.Add(fd);
            Db.SaveChanges();
            MessageBox.Show("One flight details added");

        }
    }
}
